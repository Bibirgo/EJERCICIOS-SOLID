package edu.itvo.sistemadegestindecursos

import models.*
import logic.*
import org.junit.Before
import org.junit.Test
import org.junit.Assert.*

class TestCourse {

    // Definimos las variables que usaremos en todas las pruebas
    private lateinit var sistema: CourseSystem
    private lateinit var validador: RegistrationValidator

    @Before
    fun configurarEscenario() {
        validador = RegistrationValidator()
        sistema = CourseSystem(validador)
    }

    @Test
    fun `no debe permitir mas de 30 estudiantes por curso`() {
        val profe = Teacher("Ambrosio Cardoso Jimenez", "Programacion")
        val curso = Course("Moviles II", "ACJ", profe)

        repeat(30) { i ->
            val alumno = Student("${i + 1}", "Alumno ${i + 1}")
            sistema.inscribirEstudiante(alumno, curso)
        }

        val alumno31 = Student("31", "Bibiana Rubi Gaytan Ortiz")
        val resultado = sistema.inscribirEstudiante(alumno31, curso)

        assertFalse("El curso no debería aceptar al estudiante 31", resultado)
    }

    @Test
    fun `un estudiante no puede inscribirse dos veces al mismo curso`() {
        val curso = Course(" Desarrollo Frond End", "BRS", Teacher("Benedicto Ramirez Santiago", "TI"))
        val alumno = Student("100", "Eneyda Juliet Celis Aragon")

        // Primera inscripción
        sistema.inscribirEstudiante(alumno, curso)

        // Segunda inscripción
        val resultadoSegunda = sistema.inscribirEstudiante(alumno, curso)

        assertFalse("No se debe permitir duplicar la inscripción", resultadoSegunda)
    }

    @Test
    fun `mostrar reportes de inscritos en consola`() {
        val cursoBI = Course("Inteligencia de Negocios", "ALHY", Teacher("Profe 1", "Analisis de datos"))
        val alumno1 = Student("1", "Bibiana Rubi")
        val alumno2 = Student("2", "Eneyda Juliet")

        sistema.inscribirEstudiante(alumno1, cursoBI)
        sistema.inscribirEstudiante(alumno2, cursoBI)

        val inscritos = sistema.obtenerEstudiantesPorCurso(cursoBI)

        println("\n--- REPORTE DE SISTEMA ---")
        println("Curso: ${cursoBI.nombre}")
        inscritos.forEach { println("Nombre: ${it.nombre} (ID: ${it.id})") }
        println("--------------------------\n")

        assertEquals(2, inscritos.size)
    }
}