package models

data class Teacher(
    val nombre: String,
    val especialidad: String
)

