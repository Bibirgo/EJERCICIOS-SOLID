package models

data class Student(
    val id: String,
    val nombre: String,
    val cursosInscritos: MutableList<Course> = mutableListOf()
)

