package models

data class Course(
    val nombre: String,
    val codigo: String,
    val profesor: Teacher,
    val estudiantes: MutableList<Student> = mutableListOf()
)

