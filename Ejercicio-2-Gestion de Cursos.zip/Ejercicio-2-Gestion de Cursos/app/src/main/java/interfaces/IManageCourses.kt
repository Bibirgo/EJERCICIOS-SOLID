package interfaces

import models.Course
import models.Student

interface IManageCourses {
    fun inscribirEstudiante(estudiante: Student, curso: Course): Boolean
    fun obtenerEstudiantesPorCurso(curso: Course): List<Student>
    fun obtenerCursosPorEstudiante(estudiante: Student): List<Course>
}