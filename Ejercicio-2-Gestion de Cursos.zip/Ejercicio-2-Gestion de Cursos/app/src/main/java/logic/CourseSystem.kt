package logic

import models.Course
import models.Student
import interfaces.IManageCourses

class CourseSystem(private val validador: RegistrationValidator) : IManageCourses {

    override fun inscribirEstudiante(estudiante: Student, curso: Course): Boolean {
        // 1. Validar duplicidad
        if (curso.estudiantes.contains(estudiante)) {
            println("ERROR: El alumno ${estudiante.nombre} no se puede inscribir dos veces al mismo curso.")
            return false
        }

        // 2. Validar cupo
        if (curso.estudiantes.size >= 30) {
            println("ERROR: No se pudo inscribir a ${estudiante.nombre}. El cupo del grupo es de 30.")
            return false
        }

        // Si pasa las validaciones, procedemos
        curso.estudiantes.add(estudiante)
        estudiante.cursosInscritos.add(curso)
        println("ÉXITO: ${estudiante.nombre} inscrito en ${curso.nombre}.")
        return true
    }

    override fun obtenerEstudiantesPorCurso(curso: Course) = curso.estudiantes

    override fun obtenerCursosPorEstudiante(estudiante: Student) = estudiante.cursosInscritos
}