package logic

import models.Course
import models.Student


class RegistrationValidator {
    fun puedeInscribirse(estudiante: Student, curso: Course): Boolean {
        val tieneCupo = curso.estudiantes.size < 30
        val noEstaInscrito = !curso.estudiantes.contains(estudiante)
        return tieneCupo && noEstaInscrito
    }
}


