package logic
import models.Product



class StockValidator {


    fun hayStockSuficiente(productos: List<Product>): Boolean {
        return productos.all { it.stock > 0 }
    }
}
