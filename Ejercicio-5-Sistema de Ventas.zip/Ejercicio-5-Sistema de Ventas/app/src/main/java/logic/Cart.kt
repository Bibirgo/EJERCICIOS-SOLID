package logic

import models.Product

class Cart {

    val productosSeleccionados = mutableListOf<Product>()

    fun agregarProducto(producto: Product) {

        productosSeleccionados.add(producto)
    }

    fun vaciar() {
        productosSeleccionados.clear()
    }
}
