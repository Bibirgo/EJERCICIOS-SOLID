package logic

import interfaces.StoreSystem
import logic.StockValidator
import models.Customer
import models.Order

class SystemStore(private val validador: StockValidator) : StoreSystem {

    override fun procesarCompra(cliente: Customer, carrito: Cart): Boolean {
        val lista = carrito.productosSeleccionados

        if (!validador.hayStockSuficiente(lista)) {
            println("ERROR: No hay stock suficiente para completar la orden.")
            return false
        }

        // Calcular total con 16% de IVA (Impuestos)
        val subtotal = lista.sumOf { it.precio }
        val total = subtotal * 1.16

        // Registrar orden y actualizar stock
        val nuevaOrden = Order(cliente, lista.toList(), "2026-02-19", total)
        cliente.historialCompras.add(nuevaOrden)

        lista.forEach { it.stock -= 1 } // Reducir stock

        println("ORDEN GENERADA: Total a pagar (IVA incluido): $${String.format("%.2f", total)}")
        carrito.vaciar()
        return true
    }
}