package models


data class Order(
        val cliente: Customer,
        val productos: List<Product>,
        val fecha: String,
        val total: Double
    )
