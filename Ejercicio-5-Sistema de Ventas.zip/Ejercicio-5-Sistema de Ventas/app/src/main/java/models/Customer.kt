package models


data class Customer(
        val nombre: String,
        val correo: String,
        val historialCompras: MutableList<Order> = mutableListOf()
    )
