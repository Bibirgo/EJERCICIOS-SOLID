package models

data class Product(
    val nombre: String,
    var precio: Double,
    var stock: Int
)
