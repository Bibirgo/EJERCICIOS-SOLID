package edu.itvo.sistemadeventas

import models.*
import logic.*
import org.junit.Before
import org.junit.Test
import org.junit.Assert.*

class TestStore {

    private lateinit var validador: StockValidator
    private lateinit var sistema: SystemStore

    @Before
    fun setUp() {
        // Inicialización centralizada para limpieza de código
        validador = StockValidator()
        sistema = SystemStore(validador)
    }

    @Test
    fun `debe verificar stock antes de confirmar la orden`() {
        // Producto agotado: Laptop Gaming
        val laptop = Product("Laptop Gaming", 25000.0, 0)
        val cliente = Customer("Bibiana Rubi Gaytan Ortiz", "bibianagaytan417@gmail.com")
        val carrito = Cart().apply { agregarProducto(laptop) }

        val resultadoCompra = sistema.procesarCompra(cliente, carrito)

        println("Cliente: ${cliente.nombre} | Error: Stock insuficiente para ${laptop.nombre} | Orden: No generada")
        assertFalse(resultadoCompra)
    }

    @Test
    fun `debe calcular el total aplicando el 16 por ciento de impuestos`() {
        // Producto: Cámara Sony ($5000)
        val producto = Product("Camara Sony", 5000.0, 10)
        val cliente = Customer("Rubi", "Rubi@gmail.com")
        val carrito = Cart().apply { agregarProducto(producto) }

        sistema.procesarCompra(cliente, carrito)

        // Cálculo: 5000 * 1.16 = 5800.0
        val totalEsperado = 5800.0
        val totalReal = cliente.historialCompras.last().total

        println("Cliente: ${cliente.nombre} | Error: Ninguno | Orden Generada: #001 - Total: $totalReal (IVA incluido)")
        assertEquals(totalEsperado, totalReal, 0.01)
    }

    @Test
    fun `debe registrar la orden en el historial del cliente despues de la compra`() {
        // Producto: Tablet Samsung
        val producto = Product("Tablet Samsung", 8000.0, 5)
        val cliente = Customer("Eneyda Juliet", "EneydaJul@gmail.com")
        val carrito = Cart().apply { agregarProducto(producto) }

        sistema.procesarCompra(cliente, carrito)

        println("Cliente: ${cliente.nombre} | Error: Ninguno | Orden Generada: Registrada en Historial (${cliente.historialCompras.size} pedido)")
        assertEquals(1, cliente.historialCompras.size)
    }
}