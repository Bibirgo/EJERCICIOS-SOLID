package edu.itvo.gestiondeeventos

import models.*
import logic.*
import org.junit.Before
import org.junit.Test
import org.junit.Assert.*

class EventsTest {

    private lateinit var validador: ValidatorSchedule
    private lateinit var sistema: SystemEvents

    @Before
    fun setUp() {
        // Inicialización única para mantener el orden y limpieza
        validador = ValidatorSchedule()
        sistema = SystemEvents(validador)
    }

    @Test
    fun `no debe permitir que un asistente se inscriba en actividades solapadas`() {
        val ponente = Speaker("Ambrosio Cardoso Jiménez", "Programacion")
        val taller1 = Activity("Taller Arquitectura de Software Limpia", ponente, 800, 1100, 11)
        val taller2 = Activity("Inteligencia de Negocios", ponente, 1000, 1200, 11)
        val asistente = Assistant("Bibiana Rubi", "bibianagaytan2602@gmail.com")

        // Intento 1
        val res1 = sistema.inscribirAsistente(asistente, taller1)
        println("Asistente: ${asistente.nombre} | Actividad: ${taller1.nombre} | Imparte: ${taller1.ponente.nombre} | Hora: ${taller1.horaInicio} | Resultado: ${if(res1) "EXITOSO" else "FALLIDO"}")

        // Intento 2 (Solapado)
        val res2 = sistema.inscribirAsistente(asistente, taller2)
        println("Asistente: ${asistente.nombre} | Actividad: ${taller2.nombre} | Imparte: ${taller2.ponente.nombre} | Hora: ${taller2.horaInicio} | Resultado: ${if(res2) "EXITOSO" else "FALLIDO"}")

        assertFalse(res2)
    }

    @Test
    fun `debe validar el cupo maximo por actividad`() {
        val ponente = Speaker("Ambrosio Cardoso Jiménez", "Programacion")
        val charla = Activity("Platica Aplicación de SOLID", ponente, 1500, 1600, 2)

        val asistentes = listOf(
            Assistant("User 1", "u1@test.com"),
            Assistant("User 2", "u2@test.com"),
            Assistant("User 3", "u3@test.com")
        )

        asistentes.forEach { asistente ->
            val res = sistema.inscribirAsistente(asistente, charla)
            println("Asistente: ${asistente.nombre} | Actividad: ${charla.nombre} | Imparte: ${ponente.nombre} | Hora: ${charla.horaInicio} | Resultado: ${if(res) "EXITOSO" else "FALLIDO (CUPO LLENO)"}")
        }
    }

    @Test
    fun `debe mostrar el cronograma ordenado por asistente`() {
        val asistente = Assistant("Bibiana Rubi", "bibianagaytan2602@gmail.com")
        val ponente = Speaker("P1", "D")
        val tarde = Activity("Cierre", ponente, 1500, 1700, 20)
        val mañana = Activity("Apertura", ponente, 900, 1200, 20)

        sistema.inscribirAsistente(asistente, tarde)
        sistema.inscribirAsistente(asistente, mañana)

        val cronograma = sistema.obtenerCronogramaAsistente(asistente)

        println("\n--- REPORTE DE CRONOGRAMA ---")
        cronograma.forEach { act ->
            println("Asistente: ${asistente.nombre} | Imparte: ${act.ponente.nombre} | Hora: ${act.horaInicio} hrs | Actividad: ${act.nombre}")
        }
        println("------------------------------")

        assertEquals("Apertura", cronograma[0].nombre)
    }
}