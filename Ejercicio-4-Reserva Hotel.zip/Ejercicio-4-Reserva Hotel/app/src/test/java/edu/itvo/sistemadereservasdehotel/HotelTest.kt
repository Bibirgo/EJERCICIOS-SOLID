package edu.itvo.sistemadereservasdehotel

import models.*
import logic.*
import org.junit.Before
import org.junit.Test
import org.junit.Assert.*

class HotelTest {

    private lateinit var validador: ReservationValidator
    private lateinit var sistema: ReservationsSystem

    @Before
    fun setUp() {
        // Inicialización única: Principio de Inversión de Dependencias (DIP)
        validador = ReservationValidator()
        sistema = ReservationsSystem(validador)
    }

    @Test
    fun `verificar disponibilidad y calcular costo por noches`() {
        // Habitación Suite: $600.0 por noche
        val hab = Room(101, "Suite", 600.0)
        val cliente = Guest("Bibiana Rubi Gaytan Ortiz", "22920147")

        // Reserva por 4 noches
        val exito = sistema.crearReserva(cliente, hab, 4)

        assertTrue("La reserva debería ser exitosa", exito)

        // Cálculo: 600.0 * 4 = 2400.0
        val totalReal = cliente.historialReservas.last().total
        assertEquals(2400.0, totalReal, 0.0)
        assertFalse("La habitación debe estar ocupada", hab.disponible)

        println("Reserva 1 - Cliente: ${cliente.nombre} | Total: $$totalReal | Estado Habitación: Ocupada")
    }

    @Test
    fun `no debe permitir reservar una habitacion ocupada`() {
        val hab = Room(200, "Sencilla", 400.0)
        val cliente1 = Guest("Bibiana Rubi", "9514415705")
        val cliente2 = Guest("Ambrosio Cardoso Jimenez", "DNI002")

        // Cliente 1 reserva primero
        sistema.crearReserva(cliente1, hab, 2)

        // Cliente 2 intenta reservar la misma habitación
        val resultado = sistema.crearReserva(cliente2, hab, 1)

        assertFalse("El sistema bloqueó la doble reserva correctamente", resultado)
        println("Reserva 2 - Intento de doble reserva bloqueado con éxito")
    }

    @Test
    fun `cancelar reserva y liberar habitacion`() {
        val hab = Room(300, "Doble", 500.0)
        val cliente = Guest("Eneyda Juliet", "9510000000")

        sistema.crearReserva(cliente, hab, 3)
        val reservaParaCancelar = cliente.historialReservas.last()

        // Proceso de cancelación
        sistema.cancelarReserva(cliente, reservaParaCancelar)

        assertTrue("La habitación quedó libre para otros clientes", hab.disponible)
        assertEquals(0, cliente.historialReservas.size)
        println("Reserva 3 - Cancelación exitosa | Habitación ${hab.numero} ahora disponible: ${hab.disponible}")
    }
}