package logic

import models.Room

class ReservationValidator {

    fun estaDisponible(habitacion: Room): Boolean = habitacion.disponible
}