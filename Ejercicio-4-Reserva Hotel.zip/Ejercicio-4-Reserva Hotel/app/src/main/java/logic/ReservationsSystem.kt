package logic

import interfaces.IReservationSystem
import models.Booking
import models.Guest
import models.Room

class ReservationsSystem(private val validador: ReservationValidator) : IReservationSystem {

    override fun crearReserva(huesped: Guest, habitacion: Room, noches: Int): Boolean {
        if (validador.estaDisponible(habitacion)) {
            val total = habitacion.precioPorNoche * noches
            val nuevaReserva = Booking(habitacion, huesped, noches, total)

            habitacion.disponible = false
            huesped.historialReservas.add(nuevaReserva)

            println("ÉXITO: Reserva creada para ${huesped.nombre}. Total: $$total")
            return true
        }
        println("ERROR: La habitación ${habitacion.numero} no está disponible.")
        return false
    }

    override fun cancelarReserva(huesped: Guest, reserva: Booking) {
        reserva.habitacion.disponible = true
        huesped.historialReservas.remove(reserva)
        println("CANCELACIÓN: Habitación ${reserva.habitacion.numero} liberada.")
    }
}