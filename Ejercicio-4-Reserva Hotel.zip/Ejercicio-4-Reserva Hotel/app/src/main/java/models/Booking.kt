package models

data class Booking(
    val habitacion: Room,
    val huesped: Guest,
    val noches: Int,
    val total: Double
)