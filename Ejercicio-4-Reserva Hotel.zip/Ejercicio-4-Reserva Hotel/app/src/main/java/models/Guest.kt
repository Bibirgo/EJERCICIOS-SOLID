package models

data class Guest(
    val nombre: String,
    val dni: String,
    val historialReservas: MutableList<Booking> = mutableListOf()
)