package models

data class Room(
    val numero: Int,
    val tipo: String,
    val precioPorNoche: Double,
    var disponible: Boolean = true
)