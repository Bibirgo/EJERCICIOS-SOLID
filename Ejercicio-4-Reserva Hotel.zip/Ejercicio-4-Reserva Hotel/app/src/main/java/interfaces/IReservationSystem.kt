package interfaces

import models.Booking
import models.Guest
import models.Room

interface IReservationSystem {


        fun crearReserva(huesped: Guest, habitacion: Room, noches: Int): Boolean
        fun cancelarReserva(huesped: Guest, reserva: Booking)

}