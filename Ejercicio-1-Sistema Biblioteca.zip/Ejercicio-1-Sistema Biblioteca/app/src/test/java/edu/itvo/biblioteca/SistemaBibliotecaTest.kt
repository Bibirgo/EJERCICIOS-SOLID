package edu.itvo.biblioteca

import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class SistemaBibliotecaTest {

    private lateinit var biblioteca: Biblioteca
    private lateinit var prestamos: Prestamos
    private lateinit var usuarioPrincipal: Usuario

    @Before
    fun setUp() {
        // Inicialización centralizada para consistencia en las pruebas
        biblioteca = Biblioteca()
        prestamos = Prestamos(biblioteca)

        usuarioPrincipal = Usuario(id = 1, nombre = "Bibiana Rubi")

        // Catálogo de libros con autores específicos
        val catalogoInicial = listOf(
            Libro("SOLID", "Ambrosio Cardoso Jimenez", "101"),
            Libro("POO", "Autor X", "102"),
            Libro("CISCO", "Francisco Javier Trujillo Lopez", "103"),
            Libro("JAVA", "Benedicto Ramirez Santiago", "999")
        )

        biblioteca.libros.addAll(catalogoInicial)
        biblioteca.usuarios.add(usuarioPrincipal)
    }

    @Test
    fun `validar que un usuario no pueda tener mas de 3 libros`() {
        val libros = biblioteca.libros

        // Simulamos el préstamo de los primeros 3 libros
        for (i in 0..2) {
            prestamos.prestarLibro(libros[i], usuarioPrincipal)
        }

        // Intento de préstamo del 4to libro
        val cuartoLibro = libros[3]
        val autorizado = prestamos.autorizaPrestamo(usuarioPrincipal.id, cuartoLibro.isbn)

        // Impresión de Resultado solicitado
        println("--- REPORTE: LÍMITE DE PRÉSTAMOS ---")
        println("Asistente/Usuario: ${usuarioPrincipal.nombre}")
        println("Libro: ${cuartoLibro.titulo} | Autor: ${cuartoLibro.autor}")
        println("Resultado: ${if (autorizado) "PRESTADO" else "RECHAZADO (Límite de 3 alcanzado)"}")
        println("------------------------------------\n")

        assertFalse("El sistema no debe permitir más de 3 libros por usuario", autorizado)
    }

    @Test
    fun `no debe prestar un libro que ya no esta disponible`() {
        val libroObjetivo = biblioteca.libros.first { it.isbn == "999" }
        val segundoUsuario = Usuario(id = 2, nombre = "Rubi")

        // El primer usuario toma el libro
        prestamos.prestarLibro(libroObjetivo, usuarioPrincipal)

        // El segundo usuario intenta tomar el mismo libro
        val autorizado = prestamos.autorizaPrestamo(segundoUsuario.id, libroObjetivo.isbn)

        // Impresión de Resultado solicitado
        println("--- REPORTE: DISPONIBILIDAD ---")
        println("Libro: ${libroObjetivo.titulo} | Autor: ${libroObjetivo.autor}")
        println("Intento de préstamo por: ${segundoUsuario.nombre}")
        println("Resultado: ${if (autorizado) "ÉXITO" else "FALLIDO (El libro ya está en préstamo)"}")
        println("-------------------------------\n")

        assertFalse("No se puede prestar un libro que ya tiene otro usuario", autorizado)
    }

    @Test
    fun `mostrar libros disponibles en consola`() {
        // Ocupamos el libro de POO para la prueba
        val libroPOO = biblioteca.libros.first { it.titulo == "POO" }
        prestamos.prestarLibro(libroPOO, usuarioPrincipal)

        val disponibles = biblioteca.libros.filter { it.disponible }

        println("--- REPORTE: CATÁLOGO DISPONIBLE ---")
        disponibles.forEach { libro ->
            println("Título: ${libro.titulo.padEnd(15)} | Autor: ${libro.autor.padEnd(30)} | Estado: DISPONIBLE")
        }
        println("Total disponibles: ${disponibles.size}")
        println("------------------------------------\n")

        assertEquals(3, disponibles.size)
    }
}